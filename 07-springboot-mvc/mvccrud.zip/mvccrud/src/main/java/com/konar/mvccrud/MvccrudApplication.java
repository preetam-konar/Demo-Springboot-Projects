package com.konar.mvccrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvccrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvccrudApplication.class, args);
	}

}
